
package autograde.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author juanr
 */
public class ConexionDB {
    
    public ConexionDB(){
        
    }
    //Se genera una variable que guarda el estdo de la conexion
    private static Connection conexion;
    //Generamos una variable para crear una sola instancia
    private static ConexionDB instancia;
    
    private static final String driver = "com.mysql.jbdc.Driver";
    private static final String user = "root";
    private static final String pass = "";
    private static final String url = "jdbc:mysql://localhost:3306/usuario";

    /**
     *
     */
    //Funcion que se conecta a la base de datos:
    public  Connection Conecta(){
        
        //Reinicio a conectar base de datos cada que se reinicie el programa
        conexion = null;
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            
            conexion = DriverManager.getConnection(url,user,pass);
            
            System.out.println("Conexion exitosa");
            return conexion;
        }catch(Exception e){
            System.out.println("Conexion fallida" + e);
        }
        return conexion;
    }
}
